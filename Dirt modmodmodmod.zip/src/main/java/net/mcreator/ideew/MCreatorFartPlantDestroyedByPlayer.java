package net.mcreator.ideew;

import net.minecraft.world.World;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.Entity;

import java.util.HashMap;

@Elementsideew.ModElement.Tag
public class MCreatorFartPlantDestroyedByPlayer extends Elementsideew.ModElement {
	public MCreatorFartPlantDestroyedByPlayer(Elementsideew instance) {
		super(instance, 1);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure MCreatorFartPlantDestroyedByPlayer!");
			return;
		}
		if (dependencies.get("world") == null) {
			System.err.println("Failed to load dependency world for procedure MCreatorFartPlantDestroyedByPlayer!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		World world = (World) dependencies.get("world");
		if (!world.isRemote) {
			world.createExplosion(null, (int) 0, (int) 0, (int) 0, (float) 4, true);
		}
		world.addWeatherEffect(new EntityLightningBolt(world, (int) 0, (int) 0, (int) 0, false));
		entity.setFire((int) 15);
	}
}
