package net.mcreator.ideew;

import net.minecraft.block.Block;

import java.util.HashMap;

@Elementsideew.ModElement.Tag
public class MCreatorFartMobplayerCollidesWithPlant extends Elementsideew.ModElement {
	public MCreatorFartMobplayerCollidesWithPlant(Elementsideew instance) {
		super(instance, 2);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("block") == null) {
			System.err.println("Failed to load dependency block for procedure MCreatorFartMobplayerCollidesWithPlant!");
			return;
		}
		Block block = (Block) dependencies.get("block");
		block.setLightLevel((float) 100);
	}
}
