package net.mcreator.ideew;

import net.minecraft.util.DamageSource;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.Entity;

import java.util.HashMap;

@Elementsideew.ModElement.Tag
public class MCreatorFartMobplayerCollidesWithPlanslow extends Elementsideew.ModElement {
	public MCreatorFartMobplayerCollidesWithPlanslow(Elementsideew instance) {
		super(instance, 3);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure MCreatorFartMobplayerCollidesWithPlanslow!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if ((entity.isSneaking())) {
			if (entity instanceof EntityPlayer)
				((EntityPlayer) entity).inventory.clear();
		} else if ((entity.isSprinting())) {
			entity.attackEntityFrom(DamageSource.GENERIC, (float) 1);
		}
		if ((entity.isBurning())) {
			if (entity instanceof EntityPlayer)
				((EntityPlayer) entity).capabilities.disableDamage = (true);
		}
	}
}
