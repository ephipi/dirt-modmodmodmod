package net.mcreator.ideew;

import net.minecraft.world.World;
import net.minecraft.entity.projectile.EntityTippedArrow;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.Entity;

import java.util.HashMap;

@Elementsideew.ModElement.Tag
public class MCreatorCloudRandomTickUpdateEvent extends Elementsideew.ModElement {
	public MCreatorCloudRandomTickUpdateEvent(Elementsideew instance) {
		super(instance, 14);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure MCreatorCloudRandomTickUpdateEvent!");
			return;
		}
		if (dependencies.get("world") == null) {
			System.err.println("Failed to load dependency world for procedure MCreatorCloudRandomTickUpdateEvent!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		World world = (World) dependencies.get("world");
		if (!world.isRemote && entity instanceof EntityLivingBase) {
			EntityTippedArrow entityToSpawn = new EntityTippedArrow(world, (EntityLivingBase) entity);
			entityToSpawn.shoot(entity.getLookVec().x, entity.getLookVec().y, entity.getLookVec().z, ((float) 1) * 2.0F, 0);
			entityToSpawn.setDamage(((float) 5) * 2.0F);
			entityToSpawn.setKnockbackStrength((int) 5);
			world.spawnEntity(entityToSpawn);
		}
	}
}
