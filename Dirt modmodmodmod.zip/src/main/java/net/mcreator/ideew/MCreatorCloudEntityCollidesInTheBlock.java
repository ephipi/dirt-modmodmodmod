package net.mcreator.ideew;

import net.minecraft.entity.Entity;

import java.util.HashMap;

@Elementsideew.ModElement.Tag
public class MCreatorCloudEntityCollidesInTheBlock extends Elementsideew.ModElement {
	public MCreatorCloudEntityCollidesInTheBlock(Elementsideew instance) {
		super(instance, 13);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure MCreatorCloudEntityCollidesInTheBlock!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		entity.setInWeb();
	}
}
