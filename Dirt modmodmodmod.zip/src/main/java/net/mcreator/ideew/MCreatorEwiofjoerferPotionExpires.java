package net.mcreator.ideew;

import net.minecraft.util.DamageSource;
import net.minecraft.entity.Entity;

import java.util.HashMap;

@Elementsideew.ModElement.Tag
public class MCreatorEwiofjoerferPotionExpires extends Elementsideew.ModElement {
	public MCreatorEwiofjoerferPotionExpires(Elementsideew instance) {
		super(instance, 9);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure MCreatorEwiofjoerferPotionExpires!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		entity.attackEntityFrom(DamageSource.GENERIC, (float) 1000);
	}
}
